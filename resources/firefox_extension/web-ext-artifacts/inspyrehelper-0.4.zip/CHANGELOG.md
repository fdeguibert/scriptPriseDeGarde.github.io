## version 0.2
publiée.  
ajoute la création d'une prise de garde  

## version 0.3
publiée.  
ajoute la gestion de la mise à jour automatique Firefox  

## version 0.4
dev en cours.
ajoute la signature de fin de garde

